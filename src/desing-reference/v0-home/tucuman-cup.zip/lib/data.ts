// Tucumán Cup — mock football data layer
// Realistic tournament content for a premium championship portal.

export type TeamId =
  | 'atl'
  | 'smt'
  | 'con'
  | 'vmi'
  | 'bvi'
  | 'agu'
  | 'nun'
  | 'gra'
  | 'tal'
  | 'jve'
  | 'mon'
  | 'cro'

export interface Team {
  id: TeamId
  name: string
  short: string
  city: string
  founded: number
  stadium: string
  color: string // hex for crest tint
  coach: string
}

export const teams: Record<TeamId, Team> = {
  atl: { id: 'atl', name: 'Atlético Central', short: 'ATL', city: 'San Miguel', founded: 1902, stadium: 'El Coloso del Norte', color: '#3b7dd8', coach: 'Rubén Darío Insúa' },
  smt: { id: 'smt', name: 'San Martín', short: 'SMT', city: 'Ciudadela', founded: 1909, stadium: 'La Ciudadela', color: '#d84343', coach: 'Pablo De Muner' },
  con: { id: 'con', name: 'Concepción FC', short: 'CON', city: 'Concepción', founded: 1918, stadium: 'Parque Sur', color: '#2fae6a', coach: 'Leandro Gracián' },
  vmi: { id: 'vmi', name: 'Villa Mitre', short: 'VMI', city: 'Banda del Río', founded: 1921, stadium: 'La Bombonerita', color: '#e0a92f', coach: 'Marcelo Vázquez' },
  bvi: { id: 'bvi', name: 'Bella Vista', short: 'BVI', city: 'Bella Vista', founded: 1925, stadium: 'El Azucarero', color: '#8a4fd8', coach: 'Diego Cagna' },
  agu: { id: 'agu', name: 'Dep. Aguilares', short: 'AGU', city: 'Aguilares', founded: 1931, stadium: 'Sur Profundo', color: '#d86a2f', coach: 'Facundo Sava' },
  nun: { id: 'nun', name: 'Ñuñorco', short: 'ÑUÑ', city: 'Monteros', founded: 1928, stadium: 'El Cerro', color: '#2f9ed8', coach: 'Sergio Gómez' },
  gra: { id: 'gra', name: 'Graneros United', short: 'GRA', city: 'Graneros', founded: 1934, stadium: 'La Frontera', color: '#c0392b', coach: 'Andrés Yllana' },
  tal: { id: 'tal', name: 'Talleres del Norte', short: 'TAL', city: 'Tafí Viejo', founded: 1913, stadium: 'El Taller', color: '#4a4a4a', coach: 'Gustavo Coleoni' },
  jve: { id: 'jve', name: 'Juventud Verde', short: 'JVE', city: 'Yerba Buena', founded: 1937, stadium: 'El Bosque', color: '#27ae60', coach: 'Ariel Broggi' },
  mon: { id: 'mon', name: 'Monteros AC', short: 'MON', city: 'Monteros', founded: 1922, stadium: 'Valle Alto', color: '#9b59b6', coach: 'Emiliano Vecchio' },
  cro: { id: 'cro', name: 'Croix del Sur', short: 'CRO', city: 'Simoca', founded: 1930, stadium: 'La Cruz', color: '#e67e22', coach: 'Darío Franco' },
}

export const teamList: Team[] = Object.values(teams)

export interface StandingRow {
  team: TeamId
  played: number
  won: number
  drawn: number
  lost: number
  gf: number
  ga: number
  points: number
  form: ('W' | 'D' | 'L')[]
}

export const standings: StandingRow[] = [
  { team: 'atl', played: 18, won: 13, drawn: 3, lost: 2, gf: 38, ga: 15, points: 42, form: ['W', 'W', 'D', 'W', 'W'] },
  { team: 'con', played: 18, won: 12, drawn: 4, lost: 2, gf: 34, ga: 17, points: 40, form: ['W', 'D', 'W', 'W', 'L'] },
  { team: 'smt', played: 18, won: 11, drawn: 3, lost: 4, gf: 31, ga: 19, points: 36, form: ['L', 'W', 'W', 'D', 'W'] },
  { team: 'bvi', played: 18, won: 9, drawn: 6, lost: 3, gf: 28, ga: 18, points: 33, form: ['D', 'W', 'D', 'W', 'D'] },
  { team: 'jve', played: 18, won: 9, drawn: 4, lost: 5, gf: 26, ga: 22, points: 31, form: ['W', 'L', 'W', 'W', 'L'] },
  { team: 'vmi', played: 18, won: 8, drawn: 5, lost: 5, gf: 24, ga: 21, points: 29, form: ['D', 'W', 'L', 'D', 'W'] },
  { team: 'nun', played: 18, won: 7, drawn: 5, lost: 6, gf: 22, ga: 23, points: 26, form: ['L', 'D', 'W', 'L', 'W'] },
  { team: 'mon', played: 18, won: 6, drawn: 6, lost: 6, gf: 21, ga: 24, points: 24, form: ['D', 'D', 'L', 'W', 'D'] },
  { team: 'tal', played: 18, won: 6, drawn: 4, lost: 8, gf: 19, ga: 26, points: 22, form: ['L', 'W', 'L', 'D', 'L'] },
  { team: 'agu', played: 18, won: 5, drawn: 4, lost: 9, gf: 18, ga: 29, points: 19, form: ['L', 'L', 'D', 'W', 'L'] },
  { team: 'cro', played: 18, won: 3, drawn: 5, lost: 10, gf: 15, ga: 31, points: 14, form: ['L', 'D', 'L', 'L', 'D'] },
  { team: 'gra', played: 18, won: 2, drawn: 4, lost: 12, gf: 12, ga: 37, points: 10, form: ['L', 'L', 'D', 'L', 'L'] },
]

export type MatchStatus = 'live' | 'upcoming' | 'finished' | 'halftime'

export interface MatchEvent {
  minute: number
  type: 'goal' | 'yellow' | 'red' | 'sub' | 'var'
  team: TeamId
  player: string
  detail?: string
}

export interface MatchStats {
  possession: [number, number]
  shots: [number, number]
  shotsOnTarget: [number, number]
  corners: [number, number]
  fouls: [number, number]
  offsides: [number, number]
  passes: [number, number]
  passAccuracy: [number, number]
}

export interface Match {
  id: string
  home: TeamId
  away: TeamId
  homeScore: number
  awayScore: number
  status: MatchStatus
  minute?: number
  round: string
  stage: string
  venue: string
  date: string
  time: string
  referee: string
  attendance?: number
  events: MatchEvent[]
  stats: MatchStats
  motm?: { player: string; team: TeamId; rating: number }
}

export const featuredMatch: Match = {
  id: 'm-101',
  home: 'atl',
  away: 'smt',
  homeScore: 2,
  awayScore: 1,
  status: 'live',
  minute: 74,
  round: 'Semifinal · Leg 1',
  stage: 'Knockout Stage',
  venue: 'El Coloso del Norte',
  date: 'Sat, 6 Jun 2026',
  time: '21:00',
  referee: 'Fernando Rapallini',
  attendance: 34120,
  motm: { player: 'Mateo Coronel', team: 'atl', rating: 8.7 },
  events: [
    { minute: 12, type: 'goal', team: 'atl', player: 'Mateo Coronel', detail: 'Right-foot finish' },
    { minute: 27, type: 'yellow', team: 'smt', player: 'Julián Paz' },
    { minute: 39, type: 'goal', team: 'smt', player: 'Bruno Herrera', detail: 'Header' },
    { minute: 45, type: 'var', team: 'atl', player: 'VAR Review', detail: 'Goal confirmed' },
    { minute: 58, type: 'goal', team: 'atl', player: 'Lucas Vega', detail: 'Penalty' },
    { minute: 63, type: 'sub', team: 'smt', player: 'Nicolás Ríos', detail: 'On for J. Paz' },
    { minute: 70, type: 'yellow', team: 'atl', player: 'Diego Sosa' },
  ],
  stats: {
    possession: [58, 42],
    shots: [14, 9],
    shotsOnTarget: [6, 4],
    corners: [7, 3],
    fouls: [9, 13],
    offsides: [2, 4],
    passes: [512, 371],
    passAccuracy: [87, 79],
  },
}

export const matches: Match[] = [
  featuredMatch,
  {
    id: 'm-102', home: 'con', away: 'bvi', homeScore: 1, awayScore: 1, status: 'live', minute: 61,
    round: 'Semifinal · Leg 1', stage: 'Knockout Stage', venue: 'Parque Sur', date: 'Sat, 6 Jun 2026', time: '21:00',
    referee: 'Yael Falcón Pérez', attendance: 21050,
    events: [
      { minute: 22, type: 'goal', team: 'con', player: 'Franco Díaz' },
      { minute: 55, type: 'goal', team: 'bvi', player: 'Gastón Ledesma' },
    ],
    stats: { possession: [46, 54], shots: [8, 11], shotsOnTarget: [3, 5], corners: [4, 6], fouls: [11, 8], offsides: [1, 3], passes: [388, 442], passAccuracy: [81, 85] },
  },
  {
    id: 'm-103', home: 'jve', away: 'vmi', homeScore: 0, awayScore: 0, status: 'upcoming',
    round: 'Quarterfinal · Replay', stage: 'Knockout Stage', venue: 'El Bosque', date: 'Sun, 7 Jun 2026', time: '18:30',
    referee: 'Andrés Merlos', events: [],
    stats: { possession: [50, 50], shots: [0, 0], shotsOnTarget: [0, 0], corners: [0, 0], fouls: [0, 0], offsides: [0, 0], passes: [0, 0], passAccuracy: [0, 0] },
  },
  {
    id: 'm-104', home: 'nun', away: 'mon', homeScore: 0, awayScore: 0, status: 'upcoming',
    round: 'Group F · Round 19', stage: 'Group Stage', venue: 'El Cerro', date: 'Sun, 7 Jun 2026', time: '21:00',
    referee: 'Nazareno Arasa', events: [],
    stats: { possession: [50, 50], shots: [0, 0], shotsOnTarget: [0, 0], corners: [0, 0], fouls: [0, 0], offsides: [0, 0], passes: [0, 0], passAccuracy: [0, 0] },
  },
  {
    id: 'm-105', home: 'tal', away: 'agu', homeScore: 0, awayScore: 0, status: 'upcoming',
    round: 'Group F · Round 19', stage: 'Group Stage', venue: 'El Taller', date: 'Mon, 8 Jun 2026', time: '19:00',
    referee: 'Pablo Dóvalo', events: [],
    stats: { possession: [50, 50], shots: [0, 0], shotsOnTarget: [0, 0], corners: [0, 0], fouls: [0, 0], offsides: [0, 0], passes: [0, 0], passAccuracy: [0, 0] },
  },
  {
    id: 'm-106', home: 'cro', away: 'gra', homeScore: 3, awayScore: 0, status: 'finished',
    round: 'Group F · Round 18', stage: 'Group Stage', venue: 'La Cruz', date: 'Wed, 3 Jun 2026', time: '20:00',
    referee: 'Darío Herrera', attendance: 8400,
    events: [
      { minute: 18, type: 'goal', team: 'cro', player: 'Tomás Aguirre' },
      { minute: 44, type: 'goal', team: 'cro', player: 'Iván Molina' },
      { minute: 77, type: 'goal', team: 'cro', player: 'Tomás Aguirre' },
    ],
    stats: { possession: [55, 45], shots: [16, 6], shotsOnTarget: [8, 2], corners: [9, 2], fouls: [7, 14], offsides: [3, 1], passes: [498, 356], passAccuracy: [86, 78] },
  },
  {
    id: 'm-107', home: 'smt', away: 'con', homeScore: 2, awayScore: 2, status: 'finished',
    round: 'Group F · Round 18', stage: 'Group Stage', venue: 'La Ciudadela', date: 'Wed, 3 Jun 2026', time: '22:00',
    referee: 'Fernando Espinoza', attendance: 28900,
    events: [], stats: { possession: [49, 51], shots: [12, 13], shotsOnTarget: [5, 6], corners: [5, 5], fouls: [10, 9], offsides: [2, 2], passes: [430, 451], passAccuracy: [83, 84] },
  },
]

export interface Scorer {
  rank: number
  player: string
  team: TeamId
  goals: number
  assists: number
  matches: number
  position: string
}

export const topScorers: Scorer[] = [
  { rank: 1, player: 'Mateo Coronel', team: 'atl', goals: 17, assists: 6, matches: 18, position: 'Forward' },
  { rank: 2, player: 'Franco Díaz', team: 'con', goals: 15, assists: 4, matches: 18, position: 'Forward' },
  { rank: 3, player: 'Tomás Aguirre', team: 'cro', goals: 12, assists: 3, matches: 17, position: 'Forward' },
  { rank: 4, player: 'Bruno Herrera', team: 'smt', goals: 11, assists: 8, matches: 18, position: 'Winger' },
  { rank: 5, player: 'Gastón Ledesma', team: 'bvi', goals: 10, assists: 5, matches: 16, position: 'Forward' },
  { rank: 6, player: 'Lucas Vega', team: 'atl', goals: 9, assists: 9, matches: 18, position: 'Midfielder' },
  { rank: 7, player: 'Emanuel Ortiz', team: 'jve', goals: 9, assists: 2, matches: 17, position: 'Forward' },
  { rank: 8, player: 'Santiago Luna', team: 'vmi', goals: 8, assists: 6, matches: 18, position: 'Winger' },
]

export interface Player {
  id: string
  name: string
  team: TeamId
  number: number
  position: string
  age: number
  nationality: string
  height: string
  goals: number
  assists: number
  appearances: number
  rating: number
}

export const players: Player[] = [
  { id: 'p-1', name: 'Mateo Coronel', team: 'atl', number: 9, position: 'Centre-Forward', age: 24, nationality: 'Argentina', height: '1.82m', goals: 17, assists: 6, appearances: 18, rating: 8.4 },
  { id: 'p-2', name: 'Lucas Vega', team: 'atl', number: 10, position: 'Attacking Mid', age: 27, nationality: 'Argentina', height: '1.74m', goals: 9, assists: 9, appearances: 18, rating: 8.1 },
  { id: 'p-3', name: 'Diego Sosa', team: 'atl', number: 5, position: 'Defensive Mid', age: 29, nationality: 'Uruguay', height: '1.79m', goals: 2, assists: 4, appearances: 17, rating: 7.6 },
  { id: 'p-4', name: 'Bruno Herrera', team: 'smt', number: 7, position: 'Right Winger', age: 22, nationality: 'Argentina', height: '1.71m', goals: 11, assists: 8, appearances: 18, rating: 8.0 },
  { id: 'p-5', name: 'Julián Paz', team: 'smt', number: 4, position: 'Centre-Back', age: 31, nationality: 'Argentina', height: '1.86m', goals: 1, assists: 1, appearances: 16, rating: 7.3 },
  { id: 'p-6', name: 'Franco Díaz', team: 'con', number: 11, position: 'Centre-Forward', age: 26, nationality: 'Chile', height: '1.80m', goals: 15, assists: 4, appearances: 18, rating: 8.2 },
  { id: 'p-7', name: 'Gastón Ledesma', team: 'bvi', number: 9, position: 'Second Striker', age: 25, nationality: 'Argentina', height: '1.77m', goals: 10, assists: 5, appearances: 16, rating: 7.9 },
  { id: 'p-8', name: 'Tomás Aguirre', team: 'cro', number: 19, position: 'Centre-Forward', age: 23, nationality: 'Argentina', height: '1.84m', goals: 12, assists: 3, appearances: 17, rating: 7.8 },
]

export interface NewsArticle {
  id: string
  title: string
  excerpt: string
  category: 'Match Report' | 'Feature' | 'Transfer' | 'Interview' | 'Analysis'
  author: string
  date: string
  readTime: string
  featured?: boolean
  team?: TeamId
  body: string[]
}

export const news: NewsArticle[] = [
  {
    id: 'n-1',
    title: 'Coronel strikes again as Atlético Central seize semifinal control',
    excerpt: 'A first-half masterclass from the tournament top scorer put the hosts in command of a fiery derby under the lights of El Coloso del Norte.',
    category: 'Match Report', author: 'Camila Reyes', date: '6 Jun 2026', readTime: '5 min', featured: true, team: 'atl',
    body: [
      'Under a wall of noise from 34,000 supporters, Atlético Central delivered the kind of performance that wins championships. Mateo Coronel opened the scoring inside twelve minutes, drilling low into the corner after a slick one-two on the edge of the box.',
      'San Martín responded through Bruno Herrera before the break, but a converted penalty from Lucas Vega restored the two-goal cushion and shifted the tie firmly in the hosts favour ahead of the return leg.',
      'It is a statement,” said head coach Rubén Darío Insúa. “But nothing is decided. We respect San Martín and we know the second leg will be a war.”',
    ],
  },
  {
    id: 'n-2',
    title: 'Concepción and Bella Vista locked in a tactical chess match',
    excerpt: 'Two of the tournament\u2019s finest coaches traded blows in a semifinal first leg that refused to yield a winner.',
    category: 'Analysis', author: 'Martín Ferreyra', date: '6 Jun 2026', readTime: '6 min', team: 'con',
    body: [
      'Where the derby across town roared, this tie simmered. Concepción and Bella Vista produced a study in structure, each cancelling the other out for long stretches before trading goals in the second half.',
      'Franco Díaz gave the hosts the lead with a trademark finish, only for Gastón Ledesma to level with a header from a set piece — the one area both coaches admitted could decide the tie.',
    ],
  },
  {
    id: 'n-3',
    title: 'The rise of Juventud Verde: how a village club reached the last eight',
    excerpt: 'From a training pitch beside the forest to the biggest stage in the province — the story of the tournament\u2019s great outsiders.',
    category: 'Feature', author: 'Lucía Domínguez', date: '5 Jun 2026', readTime: '8 min', team: 'jve',
    body: [
      'Ten years ago, Juventud Verde played on a bumpy pitch with wooden goalposts. Tonight they prepare for a quarterfinal replay with a place in the final four within reach.',
      'The secret, according to sporting director Ariel Broggi, is patience. We never chased shortcuts. We built players, we built a culture, and we let the results follow.',
    ],
  },
  {
    id: 'n-4',
    title: 'Golden Boot race tightens as Díaz closes the gap on Coronel',
    excerpt: 'Two goals in three matches have brought the Concepción striker within touching distance of the tournament\u2019s leading marksman.',
    category: 'Analysis', author: 'Camila Reyes', date: '4 Jun 2026', readTime: '4 min', team: 'con',
    body: [
      'The individual duel inside the collective battle has become one of the stories of the knockout rounds. Mateo Coronel leads with 17, but Franco Díaz is surging.',
    ],
  },
  {
    id: 'n-5',
    title: 'Croix del Sur end the group stage with a statement win',
    excerpt: 'A Tomás Aguirre double sealed a comfortable victory to close out an improving campaign for the Simoca side.',
    category: 'Match Report', author: 'Martín Ferreyra', date: '3 Jun 2026', readTime: '4 min', team: 'cro',
    body: [
      'Croix del Sur signed off from the group stage in style, brushing aside Graneros United behind a clinical Tomás Aguirre performance.',
    ],
  },
]

export const sponsors = [
  'AeroNorte', 'Banco del Tucumán', 'Ingenio La Trinidad', 'Cerro Azul', 'Norte Sports', 'Grupo Andino',
]

export const tournamentInfo = {
  name: 'Tucumán Cup',
  season: '2026',
  teamsCount: 12,
  matchesPlayed: 108,
  goalsScored: 288,
  avgGoals: 2.67,
  format: 'Group stage followed by knockout rounds. Twelve clubs compete across a group phase before the top eight advance to the knockout bracket, culminating in a single-match final.',
}

export function getTeam(id: TeamId): Team {
  return teams[id]
}

export function getMatch(id: string): Match | undefined {
  return matches.find((m) => m.id === id)
}

export function getArticle(id: string): NewsArticle | undefined {
  return news.find((n) => n.id === id)
}

export function getStanding(id: TeamId): StandingRow | undefined {
  return standings.find((s) => s.team === id)
}

export function teamPlayers(id: TeamId): Player[] {
  return players.filter((p) => p.team === id)
}
