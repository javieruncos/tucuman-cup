import Link from 'next/link'
import { CalendarDays, MapPin, Clock, Flag, Users, ArrowRight, Star } from 'lucide-react'
import { featuredMatch as m, getTeam } from '@/lib/data'
import { Crest } from '@/components/crest'
import { StatusBadge } from '@/components/badges'
import { Timeline } from '@/components/match/timeline'
import { StatRow } from '@/components/match/stat-comparison'

export function MatchCenter() {
  const home = getTeam(m.home)
  const away = getTeam(m.away)

  return (
    <section className="relative overflow-hidden rounded-xl border border-border bg-card">
      <div className="stadium-glow field-lines absolute inset-0" aria-hidden />
      <div className="relative grid lg:grid-cols-[minmax(0,340px)_1fr]">
        {/* LEFT — editorial info rail */}
        <div className="flex flex-col gap-6 border-b border-border p-6 lg:border-b-0 lg:border-r lg:p-8">
          <div>
            <div className="mb-3 flex items-center gap-2">
              <span className="font-display rounded bg-gold px-2 py-0.5 text-[11px] font-bold uppercase tracking-widest text-primary-foreground">
                Match Center
              </span>
              <StatusBadge status={m.status} minute={m.minute} />
            </div>
            <p className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              {m.stage}
            </p>
            <h2 className="font-display mt-1 text-2xl font-semibold uppercase leading-tight tracking-wide text-balance">
              {m.round}
            </h2>
          </div>

          <p className="text-pretty text-sm leading-relaxed text-muted-foreground">
            {home.name} lead a fiery northern derby against {away.name} under the lights of{' '}
            {m.venue}. A place in the final edges closer with every minute.
          </p>

          <dl className="grid grid-cols-1 gap-px overflow-hidden rounded-lg border border-border bg-border">
            {[
              { icon: MapPin, label: 'Venue', value: m.venue },
              { icon: CalendarDays, label: 'Date', value: m.date },
              { icon: Clock, label: 'Kick-off', value: `${m.time} · Local` },
              { icon: Flag, label: 'Referee', value: m.referee },
              { icon: Users, label: 'Attendance', value: m.attendance?.toLocaleString() ?? 'TBD' },
            ].map((r) => (
              <div key={r.label} className="flex items-center gap-3 bg-card px-4 py-3">
                <r.icon className="h-4 w-4 shrink-0 text-gold" />
                <dt className="w-24 text-xs uppercase tracking-wide text-muted-foreground">
                  {r.label}
                </dt>
                <dd className="ml-auto text-right text-sm font-medium">{r.value}</dd>
              </div>
            ))}
          </dl>

          {m.motm && (
            <div className="rounded-lg border border-gold/30 bg-gold-muted p-4">
              <div className="flex items-center gap-2 text-gold">
                <Star className="h-4 w-4 fill-gold" />
                <span className="font-display text-xs font-semibold uppercase tracking-widest">
                  Player of the Match
                </span>
              </div>
              <div className="mt-2 flex items-center justify-between">
                <div>
                  <p className="font-semibold">{m.motm.player}</p>
                  <p className="text-xs text-muted-foreground">{getTeam(m.motm.team).name}</p>
                </div>
                <span className="tabular font-display text-2xl font-bold text-gold">
                  {m.motm.rating}
                </span>
              </div>
            </div>
          )}

          <Link
            href={`/match/${m.id}`}
            className="mt-auto inline-flex items-center justify-center gap-2 rounded-md bg-secondary px-4 py-2.5 text-sm font-semibold text-secondary-foreground transition-opacity hover:opacity-90"
          >
            Open full match center <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {/* RIGHT — broadcast scoreboard + data */}
        <div className="flex flex-col">
          {/* Scoreboard */}
          <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 p-6 sm:gap-8 sm:p-10">
            <div className="flex flex-col items-center gap-3 text-center">
              <Crest team={m.home} size={88} />
              <div>
                <p className="font-display text-lg font-semibold uppercase tracking-wide sm:text-xl">
                  {home.name}
                </p>
                <p className="text-xs text-muted-foreground">{home.city}</p>
              </div>
            </div>

            <div className="flex flex-col items-center">
              <div className="flex items-center gap-3 sm:gap-5">
                <span className="animate-score-pop font-display text-6xl font-bold leading-none tabular sm:text-7xl">
                  {m.homeScore}
                </span>
                <span className="font-display text-3xl font-light text-muted-foreground sm:text-4xl">
                  :
                </span>
                <span className="animate-score-pop font-display text-6xl font-bold leading-none tabular sm:text-7xl">
                  {m.awayScore}
                </span>
              </div>
              {(m.status === 'live' || m.status === 'halftime') && (
                <span className="tabular mt-3 inline-flex items-center gap-1.5 rounded-full bg-live/15 px-3 py-1 text-sm font-semibold text-live">
                  <span className="h-1.5 w-1.5 rounded-full bg-live animate-live-pulse" />
                  {m.minute}&apos; · Live
                </span>
              )}
            </div>

            <div className="flex flex-col items-center gap-3 text-center">
              <Crest team={m.away} size={88} />
              <div>
                <p className="font-display text-lg font-semibold uppercase tracking-wide sm:text-xl">
                  {away.name}
                </p>
                <p className="text-xs text-muted-foreground">{away.city}</p>
              </div>
            </div>
          </div>

          {/* Data grid */}
          <div className="grid gap-px border-t border-border bg-border sm:grid-cols-2">
            <div className="bg-card p-6">
              <h3 className="font-display mb-4 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Live Timeline
              </h3>
              <Timeline match={m} />
            </div>
            <div className="bg-card p-6">
              <h3 className="font-display mb-4 text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                Match Statistics
              </h3>
              <div className="flex flex-col gap-4">
                <StatRow label="Possession" home={m.stats.possession[0]} away={m.stats.possession[1]} suffix="%" />
                <StatRow label="Shots" home={m.stats.shots[0]} away={m.stats.shots[1]} />
                <StatRow label="On Target" home={m.stats.shotsOnTarget[0]} away={m.stats.shotsOnTarget[1]} />
                <StatRow label="Corners" home={m.stats.corners[0]} away={m.stats.corners[1]} />
                <StatRow label="Fouls" home={m.stats.fouls[0]} away={m.stats.fouls[1]} />
                <StatRow label="Pass Accuracy" home={m.stats.passAccuracy[0]} away={m.stats.passAccuracy[1]} suffix="%" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
