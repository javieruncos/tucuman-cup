import { sponsors } from '@/lib/data'

export function Sponsors() {
  return (
    <section className="rounded-xl border border-border bg-card/40 px-6 py-8">
      <p className="font-display mb-6 text-center text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        Official Partners of the Tucumán Cup
      </p>
      <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-5">
        {sponsors.map((s) => (
          <span
            key={s}
            className="font-display text-lg font-semibold uppercase tracking-wide text-muted-foreground/60 transition-colors hover:text-foreground"
          >
            {s}
          </span>
        ))}
      </div>
    </section>
  )
}
