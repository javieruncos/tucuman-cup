import { getTeam, type TeamId } from '@/lib/data'
import { cn } from '@/lib/utils'

interface CrestProps {
  team: TeamId
  size?: number
  className?: string
}

// A generated shield-style crest so no external image assets are required.
export function Crest({ team, size = 40, className }: CrestProps) {
  const t = getTeam(team)
  return (
    <span
      className={cn('relative inline-flex shrink-0 items-center justify-center', className)}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
        <defs>
          <linearGradient id={`crest-${team}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={t.color} stopOpacity="0.95" />
            <stop offset="100%" stopColor={t.color} stopOpacity="0.55" />
          </linearGradient>
        </defs>
        <path
          d="M24 2 6 8v16c0 11 8 18 18 22 10-4 18-11 18-22V8L24 2Z"
          fill={`url(#crest-${team})`}
          stroke="rgba(255,255,255,0.28)"
          strokeWidth="1.2"
        />
        <path
          d="M24 2 6 8v16c0 11 8 18 18 22 10-4 18-11 18-22V8L24 2Z"
          fill="none"
          stroke="rgba(0,0,0,0.25)"
          strokeWidth="0.5"
          transform="scale(0.9) translate(2.6 2.4)"
        />
      </svg>
      <span
        className="font-display absolute inset-0 flex items-center justify-center font-bold text-white"
        style={{ fontSize: size * 0.3, textShadow: '0 1px 2px rgba(0,0,0,0.4)' }}
      >
        {t.short.slice(0, 3)}
      </span>
    </span>
  )
}
