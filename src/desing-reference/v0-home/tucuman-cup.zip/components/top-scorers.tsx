import { topScorers, getTeam } from '@/lib/data'
import { Crest } from '@/components/crest'
import { cn } from '@/lib/utils'

export function TopScorers({ limit }: { limit?: number }) {
  const list = limit ? topScorers.slice(0, limit) : topScorers
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      {list.map((s, i) => {
        const team = getTeam(s.team)
        return (
          <div
            key={s.player}
            className="flex items-center gap-4 border-b border-border/60 px-4 py-3.5 transition-colors last:border-0 hover:bg-elevated"
          >
            <span
              className={cn(
                'tabular font-display grid h-8 w-8 shrink-0 place-items-center rounded-md text-sm font-bold',
                i === 0 ? 'bg-gold text-primary-foreground' : 'bg-elevated text-muted-foreground',
              )}
            >
              {s.rank}
            </span>
            <Crest team={s.team} size={30} />
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{s.player}</p>
              <p className="text-xs text-muted-foreground">
                {team.short} · {s.position}
              </p>
            </div>
            <div className="hidden text-right sm:block">
              <p className="text-xs text-muted-foreground">Assists</p>
              <p className="tabular font-display font-semibold">{s.assists}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Goals</p>
              <p className="tabular font-display text-xl font-bold text-gold">{s.goals}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}
