import Link from 'next/link'
import { standings, getTeam } from '@/lib/data'
import { Crest } from '@/components/crest'
import { FormDots } from '@/components/badges'
import { cn } from '@/lib/utils'

export function StandingsTable({ compact = false }: { compact?: boolean }) {
  return (
    <div className="overflow-hidden rounded-xl border border-border bg-card">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[560px] border-collapse text-sm">
          <thead>
            <tr className="border-b border-border text-xs uppercase tracking-wide text-muted-foreground">
              <th className="px-4 py-3 text-left font-medium">#</th>
              <th className="px-2 py-3 text-left font-medium">Club</th>
              <th className="px-3 py-3 text-center font-medium">P</th>
              <th className="px-3 py-3 text-center font-medium">W</th>
              <th className="px-3 py-3 text-center font-medium">D</th>
              <th className="px-3 py-3 text-center font-medium">L</th>
              {!compact && <th className="px-3 py-3 text-center font-medium">GF</th>}
              {!compact && <th className="px-3 py-3 text-center font-medium">GA</th>}
              <th className="px-3 py-3 text-center font-medium">GD</th>
              <th className="px-3 py-3 text-center font-medium text-foreground">Pts</th>
              {!compact && <th className="hidden px-4 py-3 text-right font-medium md:table-cell">Form</th>}
            </tr>
          </thead>
          <tbody>
            {standings.map((row, i) => {
              const team = getTeam(row.team)
              const gd = row.gf - row.ga
              const qualifies = i < 4
              const relegates = i >= standings.length - 2
              return (
                <tr
                  key={row.team}
                  className="group border-b border-border/60 transition-colors last:border-0 hover:bg-elevated"
                >
                  <td className="relative px-4 py-3">
                    <span
                      className={cn(
                        'absolute inset-y-0 left-0 w-0.5',
                        qualifies ? 'bg-gold' : relegates ? 'bg-destructive/70' : 'bg-transparent',
                      )}
                    />
                    <span className="tabular font-display font-semibold">{i + 1}</span>
                  </td>
                  <td className="px-2 py-3">
                    <Link href={`/teams/${row.team}`} className="flex items-center gap-2.5 hover:text-gold">
                      <Crest team={row.team} size={26} />
                      <span className="font-medium">{compact ? team.short : team.name}</span>
                    </Link>
                  </td>
                  <td className="tabular px-3 py-3 text-center text-muted-foreground">{row.played}</td>
                  <td className="tabular px-3 py-3 text-center text-muted-foreground">{row.won}</td>
                  <td className="tabular px-3 py-3 text-center text-muted-foreground">{row.drawn}</td>
                  <td className="tabular px-3 py-3 text-center text-muted-foreground">{row.lost}</td>
                  {!compact && <td className="tabular px-3 py-3 text-center text-muted-foreground">{row.gf}</td>}
                  {!compact && <td className="tabular px-3 py-3 text-center text-muted-foreground">{row.ga}</td>}
                  <td className={cn('tabular px-3 py-3 text-center font-medium', gd > 0 ? 'text-success' : gd < 0 ? 'text-destructive' : 'text-muted-foreground')}>
                    {gd > 0 ? '+' : ''}
                    {gd}
                  </td>
                  <td className="tabular font-display px-3 py-3 text-center text-base font-bold text-gold">
                    {row.points}
                  </td>
                  {!compact && (
                    <td className="hidden px-4 py-3 md:table-cell">
                      <div className="flex justify-end">
                        <FormDots form={row.form} />
                      </div>
                    </td>
                  )}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      <div className="flex flex-wrap gap-4 border-t border-border px-4 py-3 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-1 rounded-full bg-gold" /> Semifinal qualification</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-1 rounded-full bg-destructive/70" /> Relegation</span>
      </div>
    </div>
  )
}
