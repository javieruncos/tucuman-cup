import { cn } from '@/lib/utils'

interface StatRowProps {
  label: string
  home: number
  away: number
  suffix?: string
}

export function StatRow({ label, home, away, suffix = '' }: StatRowProps) {
  const total = home + away || 1
  const homePct = (home / total) * 100
  const homeLeads = home >= away
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between text-sm">
        <span className={cn('tabular font-display font-semibold', homeLeads ? 'text-foreground' : 'text-muted-foreground')}>
          {home}
          {suffix}
        </span>
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
        <span className={cn('tabular font-display font-semibold', !homeLeads ? 'text-foreground' : 'text-muted-foreground')}>
          {away}
          {suffix}
        </span>
      </div>
      <div className="flex h-1.5 gap-1 overflow-hidden rounded-full">
        <div
          className={cn('rounded-l-full transition-all', homeLeads ? 'bg-gold' : 'bg-muted-foreground/40')}
          style={{ width: `${homePct}%` }}
        />
        <div
          className={cn('flex-1 rounded-r-full transition-all', !homeLeads ? 'bg-gold' : 'bg-muted-foreground/40')}
        />
      </div>
    </div>
  )
}
