import Link from 'next/link'
import { getTeam, type Match } from '@/lib/data'
import { Crest } from '@/components/crest'
import { StatusBadge } from '@/components/badges'

export function MatchCard({ match }: { match: Match }) {
  const home = getTeam(match.home)
  const away = getTeam(match.away)
  const played = match.status === 'finished' || match.status === 'live' || match.status === 'halftime'

  return (
    <Link
      href={`/match/${match.id}`}
      className="group block rounded-lg border border-border bg-card p-4 transition-colors hover:border-gold/40 hover:bg-elevated"
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="truncate text-xs font-medium text-muted-foreground">{match.round}</span>
        <StatusBadge status={match.status} minute={match.minute} />
      </div>
      <div className="flex items-center justify-between gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-2.5">
          <Crest team={match.home} size={32} />
          <span className="truncate text-sm font-medium">{home.name}</span>
        </div>
        <span className="tabular font-display shrink-0 px-2 text-lg font-semibold">
          {played ? match.homeScore : '–'}
        </span>
      </div>
      <div className="mt-2 flex items-center justify-between gap-2">
        <div className="flex min-w-0 flex-1 items-center gap-2.5">
          <Crest team={match.away} size={32} />
          <span className="truncate text-sm font-medium">{away.name}</span>
        </div>
        <span className="tabular font-display shrink-0 px-2 text-lg font-semibold">
          {played ? match.awayScore : '–'}
        </span>
      </div>
      <div className="mt-3 flex items-center justify-between border-t border-border pt-3 text-xs text-muted-foreground">
        <span>{match.venue}</span>
        <span>{match.status === 'upcoming' ? `${match.date} · ${match.time}` : match.date}</span>
      </div>
    </Link>
  )
}
