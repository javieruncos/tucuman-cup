import { Goal, Square, ArrowLeftRight, Video } from 'lucide-react'
import type { Match, MatchEvent } from '@/lib/data'
import { getTeam } from '@/lib/data'
import { cn } from '@/lib/utils'

function EventIcon({ type }: { type: MatchEvent['type'] }) {
  switch (type) {
    case 'goal':
      return <Goal className="h-3.5 w-3.5 text-gold" />
    case 'yellow':
      return <Square className="h-3 w-3 fill-yellow-400 text-yellow-400" />
    case 'red':
      return <Square className="h-3 w-3 fill-destructive text-destructive" />
    case 'sub':
      return <ArrowLeftRight className="h-3.5 w-3.5 text-muted-foreground" />
    case 'var':
      return <Video className="h-3.5 w-3.5 text-muted-foreground" />
  }
}

export function Timeline({ match }: { match: Match }) {
  if (match.events.length === 0) {
    return (
      <p className="py-6 text-center text-sm text-muted-foreground">
        No events yet — kick-off {match.time}.
      </p>
    )
  }
  return (
    <ol className="relative">
      <span className="absolute bottom-2 left-1/2 top-2 w-px -translate-x-1/2 bg-border" aria-hidden />
      {match.events.map((e, i) => {
        const isHome = e.team === match.home
        const team = getTeam(e.team)
        return (
          <li
            key={i}
            className={cn('relative flex items-center gap-3 py-2', isHome ? 'flex-row' : 'flex-row-reverse')}
          >
            <div className={cn('flex flex-1 items-center gap-2.5', isHome ? 'justify-end text-right' : 'justify-start text-left')}>
              <div className={cn(isHome ? 'order-1' : 'order-2')}>
                <p className="text-sm font-medium leading-tight">{e.player}</p>
                {e.detail && <p className="text-xs text-muted-foreground">{e.detail}</p>}
              </div>
              <span
                className={cn('order-2 grid h-7 w-7 shrink-0 place-items-center rounded-full border border-border bg-card', isHome ? '' : 'order-1')}
              >
                <EventIcon type={e.type} />
              </span>
            </div>
            <span className="tabular z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-border bg-elevated text-xs font-semibold text-muted-foreground">
              {e.minute}&apos;
            </span>
            <span className="sr-only">{team.name}</span>
            <div className="flex-1" />
          </li>
        )
      })}
    </ol>
  )
}
