import { getTeam, type Match } from '@/lib/data'
import { Crest } from '@/components/crest'
import { StatusBadge } from '@/components/badges'

export function ScoreboardHero({ match: m }: { match: Match }) {
  const home = getTeam(m.home)
  const away = getTeam(m.away)
  const played = m.status !== 'upcoming'

  return (
    <section className="relative overflow-hidden rounded-xl border border-border bg-card">
      <div className="stadium-glow field-lines absolute inset-0" aria-hidden />
      <div className="relative px-4 py-8 sm:px-8 sm:py-12">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <p className="font-display text-xs font-semibold uppercase tracking-widest text-gold">
            {m.stage} · {m.round}
          </p>
          <StatusBadge status={m.status} minute={m.minute} />
        </div>

        <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-4 sm:gap-10">
          <div className="flex flex-col items-center gap-4 text-center">
            <Crest team={m.home} size={104} />
            <div>
              <p className="font-display text-xl font-semibold uppercase tracking-wide sm:text-2xl">
                {home.name}
              </p>
              <p className="text-xs text-muted-foreground">{home.city}</p>
            </div>
          </div>

          <div className="flex flex-col items-center">
            {played ? (
              <div className="flex items-center gap-3 sm:gap-6">
                <span className="animate-score-pop font-display text-7xl font-bold leading-none tabular sm:text-8xl">
                  {m.homeScore}
                </span>
                <span className="font-display text-4xl font-light text-muted-foreground">:</span>
                <span className="animate-score-pop font-display text-7xl font-bold leading-none tabular sm:text-8xl">
                  {m.awayScore}
                </span>
              </div>
            ) : (
              <span className="font-display text-5xl font-bold tabular text-muted-foreground sm:text-6xl">
                {m.time}
              </span>
            )}
            <p className="mt-3 text-xs text-muted-foreground">{m.date}</p>
          </div>

          <div className="flex flex-col items-center gap-4 text-center">
            <Crest team={m.away} size={104} />
            <div>
              <p className="font-display text-xl font-semibold uppercase tracking-wide sm:text-2xl">
                {away.name}
              </p>
              <p className="text-xs text-muted-foreground">{away.city}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
