import type { ReactNode } from 'react'
import { Navbar } from './navbar'
import { Footer } from './footer'

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  )
}

export function SectionHeader({
  eyebrow,
  title,
  action,
}: {
  eyebrow?: string
  title: string
  action?: ReactNode
}) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        {eyebrow && (
          <p className="font-display mb-1 text-xs font-semibold uppercase tracking-widest text-gold">
            {eyebrow}
          </p>
        )}
        <h2 className="font-display text-2xl font-semibold uppercase tracking-wide text-balance sm:text-3xl">
          {title}
        </h2>
      </div>
      {action}
    </div>
  )
}
