import Link from 'next/link'
import { matches, getTeam } from '@/lib/data'

export function LiveTicker() {
  const items = [...matches, ...matches] // duplicate for seamless loop

  return (
    <div className="relative flex items-center border-b border-border bg-card/60">
      <div className="z-10 flex shrink-0 items-center gap-2 self-stretch border-r border-border bg-background px-4">
        <span className="h-2 w-2 rounded-full bg-live animate-live-pulse" />
        <span className="font-display text-xs font-semibold uppercase tracking-widest text-live">
          Live
        </span>
      </div>
      <div className="relative flex-1 overflow-hidden">
        <div className="flex w-max animate-ticker items-center">
          {items.map((m, i) => {
            const h = getTeam(m.home)
            const a = getTeam(m.away)
            const live = m.status === 'live' || m.status === 'halftime'
            return (
              <Link
                key={`${m.id}-${i}`}
                href={`/match/${m.id}`}
                className="group flex items-center gap-3 whitespace-nowrap border-r border-border/60 px-5 py-2.5 text-sm transition-colors hover:bg-accent/50"
              >
                <span className="font-medium text-muted-foreground group-hover:text-foreground">
                  {h.short}
                </span>
                <span className="tabular font-display text-base font-semibold">
                  {m.status === 'upcoming' ? m.time : `${m.homeScore}–${m.awayScore}`}
                </span>
                <span className="font-medium text-muted-foreground group-hover:text-foreground">
                  {a.short}
                </span>
                {live && (
                  <span className="tabular ml-1 rounded bg-live/15 px-1.5 py-0.5 text-[11px] font-semibold text-live">
                    {m.minute}&apos;
                  </span>
                )}
              </Link>
            )
          })}
        </div>
      </div>
    </div>
  )
}
