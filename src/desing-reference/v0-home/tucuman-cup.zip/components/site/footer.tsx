import Link from 'next/link'

const groups = [
  { title: 'Competition', links: [['Fixtures', '/fixtures'], ['Standings', '/standings'], ['Statistics', '/stats'], ['Tournament', '/info']] },
  { title: 'Clubs', links: [['All Teams', '/teams'], ['Players', '/stats'], ['Top Scorers', '/stats']] },
  { title: 'Media', links: [['News', '/news'], ['Match Center', '/'], ['Search', '/search']] },
  { title: 'Account', links: [['Sign in', '/login'], ['Profile', '/profile'], ['Settings', '/settings'], ['Notifications', '/notifications']] },
]

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-card/40">
      <div className="mx-auto max-w-[1400px] px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-6">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2.5">
              <span className="grid h-9 w-9 place-items-center rounded-md bg-gold text-primary-foreground">
                <span className="font-display text-lg font-bold">TC</span>
              </span>
              <span className="font-display text-lg font-semibold uppercase tracking-wide">
                Tucumán <span className="text-gold">Cup</span>
              </span>
            </div>
            <p className="mt-4 max-w-xs text-pretty text-sm leading-relaxed text-muted-foreground">
              The official digital home of the Tucumán Cup. Football under the stadium lights —
              live, always.
            </p>
          </div>
          {groups.map((g) => (
            <div key={g.title}>
              <h4 className="font-display text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                {g.title}
              </h4>
              <ul className="mt-4 space-y-2.5">
                {g.links.map(([label, href]) => (
                  <li key={label}>
                    <Link
                      href={href}
                      className="text-sm text-foreground/80 transition-colors hover:text-gold"
                    >
                      {label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-border pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-muted-foreground">
            © 2026 Tucumán Cup. A demo product concept. Not affiliated with any real league.
          </p>
          <div className="flex gap-5 text-xs text-muted-foreground">
            <Link href="/info" className="hover:text-foreground">Privacy</Link>
            <Link href="/info" className="hover:text-foreground">Terms</Link>
            <Link href="/info" className="hover:text-foreground">Accessibility</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
