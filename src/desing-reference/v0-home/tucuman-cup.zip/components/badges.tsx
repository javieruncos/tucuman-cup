import { cn } from '@/lib/utils'
import type { MatchStatus } from '@/lib/data'

export function FormDots({ form }: { form: ('W' | 'D' | 'L')[] }) {
  const map = {
    W: 'bg-success text-success-foreground',
    D: 'bg-muted text-muted-foreground',
    L: 'bg-destructive/80 text-white',
  }
  return (
    <div className="flex gap-1">
      {form.map((r, i) => (
        <span
          key={i}
          className={cn(
            'grid h-5 w-5 place-items-center rounded text-[10px] font-bold',
            map[r],
          )}
          title={r === 'W' ? 'Win' : r === 'D' ? 'Draw' : 'Loss'}
        >
          {r}
        </span>
      ))}
    </div>
  )
}

export function StatusBadge({ status, minute }: { status: MatchStatus; minute?: number }) {
  if (status === 'live') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-live/15 px-2.5 py-1 text-xs font-semibold text-live">
        <span className="h-1.5 w-1.5 rounded-full bg-live animate-live-pulse" />
        Live {minute}&apos;
      </span>
    )
  }
  if (status === 'halftime') {
    return (
      <span className="inline-flex items-center gap-1.5 rounded-full bg-gold-muted px-2.5 py-1 text-xs font-semibold text-gold">
        Half Time
      </span>
    )
  }
  if (status === 'finished') {
    return (
      <span className="inline-flex items-center rounded-full bg-muted px-2.5 py-1 text-xs font-semibold text-muted-foreground">
        Full Time
      </span>
    )
  }
  return (
    <span className="inline-flex items-center rounded-full border border-border px-2.5 py-1 text-xs font-semibold text-muted-foreground">
      Upcoming
    </span>
  )
}

export function Pill({
  children,
  className,
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full border border-border bg-card px-2.5 py-1 text-xs font-medium text-muted-foreground',
        className,
      )}
    >
      {children}
    </span>
  )
}
