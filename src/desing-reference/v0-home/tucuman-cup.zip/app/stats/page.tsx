import { SiteShell } from '@/components/site/shell'
import { PageHero } from '@/components/site/page-hero'
import { SectionHeader } from '@/components/site/shell'
import { TopScorers } from '@/components/top-scorers'
import { Crest } from '@/components/crest'
import { topScorers, standings, getTeam, tournamentInfo } from '@/lib/data'

export default function StatsPage() {
  const assistLeaders = [...topScorers].sort((a, b) => b.assists - a.assists).slice(0, 6)
  const goalsByTeam = [...standings].sort((a, b) => b.gf - a.gf)
  const maxGf = goalsByTeam[0].gf

  return (
    <SiteShell>
      <PageHero
        eyebrow="Numbers"
        title="Statistics Center"
        description="The definitive statistical picture of the Tucumán Cup — scorers, creators, and the clubs lighting up the scoreboard."
      />
      <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            ['Goals', tournamentInfo.goalsScored],
            ['Matches', tournamentInfo.matchesPlayed],
            ['Goals / Match', tournamentInfo.avgGoals],
            ['Clubs', tournamentInfo.teamsCount],
          ].map(([label, value]) => (
            <div key={label} className="rounded-xl border border-border bg-card px-5 py-4">
              <p className="tabular font-display text-3xl font-bold text-gold">{value}</p>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>

        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <SectionHeader eyebrow="Golden boot" title="Top Scorers" />
            <TopScorers />
          </div>
          <div>
            <SectionHeader eyebrow="Playmakers" title="Assist Leaders" />
            <div className="overflow-hidden rounded-xl border border-border bg-card">
              {assistLeaders.map((s, i) => (
                <div
                  key={s.player}
                  className="flex items-center gap-4 border-b border-border/60 px-4 py-3.5 last:border-0"
                >
                  <span className="tabular font-display w-6 text-center text-sm font-bold text-muted-foreground">
                    {i + 1}
                  </span>
                  <Crest team={s.team} size={30} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{s.player}</p>
                    <p className="text-xs text-muted-foreground">{getTeam(s.team).short}</p>
                  </div>
                  <p className="tabular font-display text-xl font-bold text-gold">{s.assists}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12">
          <SectionHeader eyebrow="Firepower" title="Goals by Club" />
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="flex flex-col gap-3">
              {goalsByTeam.map((row) => {
                const team = getTeam(row.team)
                return (
                  <div key={row.team} className="flex items-center gap-3">
                    <div className="flex w-32 shrink-0 items-center gap-2 sm:w-44">
                      <Crest team={row.team} size={24} />
                      <span className="truncate text-sm font-medium">{team.name}</span>
                    </div>
                    <div className="flex-1">
                      <div
                        className="h-6 rounded bg-gradient-to-r from-gold/70 to-gold transition-all"
                        style={{ width: `${(row.gf / maxGf) * 100}%` }}
                      />
                    </div>
                    <span className="tabular font-display w-8 text-right text-sm font-bold">
                      {row.gf}
                    </span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </SiteShell>
  )
}
