import Link from 'next/link'
import { notFound } from 'next/navigation'
import { ArrowLeft, MapPin, CalendarDays, Clock, Flag, Users, Star } from 'lucide-react'
import { SiteShell } from '@/components/site/shell'
import { ScoreboardHero } from '@/components/match/scoreboard-hero'
import { Timeline } from '@/components/match/timeline'
import { StatRow } from '@/components/match/stat-comparison'
import { Crest } from '@/components/crest'
import { Tabs } from '@/components/tabs'
import { getMatch, getTeam, teamPlayers, matches } from '@/lib/data'

export function generateStaticParams() {
  return matches.map((m) => ({ id: m.id }))
}

export default async function MatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const match = getMatch(id)
  if (!match) notFound()

  const home = getTeam(match.home)
  const away = getTeam(match.away)

  const info = [
    { icon: MapPin, label: 'Venue', value: match.venue },
    { icon: CalendarDays, label: 'Date', value: match.date },
    { icon: Clock, label: 'Kick-off', value: match.time },
    { icon: Flag, label: 'Referee', value: match.referee },
    { icon: Users, label: 'Attendance', value: match.attendance?.toLocaleString() ?? 'TBD' },
  ]

  const statsContent = (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="mb-6 flex items-center justify-between">
        <span className="font-display flex items-center gap-2 font-semibold uppercase tracking-wide">
          <Crest team={match.home} size={24} /> {home.short}
        </span>
        <span className="font-display flex items-center gap-2 font-semibold uppercase tracking-wide">
          {away.short} <Crest team={match.away} size={24} />
        </span>
      </div>
      <div className="flex flex-col gap-5">
        <StatRow label="Possession" home={match.stats.possession[0]} away={match.stats.possession[1]} suffix="%" />
        <StatRow label="Shots" home={match.stats.shots[0]} away={match.stats.shots[1]} />
        <StatRow label="Shots on Target" home={match.stats.shotsOnTarget[0]} away={match.stats.shotsOnTarget[1]} />
        <StatRow label="Corners" home={match.stats.corners[0]} away={match.stats.corners[1]} />
        <StatRow label="Fouls" home={match.stats.fouls[0]} away={match.stats.fouls[1]} />
        <StatRow label="Offsides" home={match.stats.offsides[0]} away={match.stats.offsides[1]} />
        <StatRow label="Passes" home={match.stats.passes[0]} away={match.stats.passes[1]} />
        <StatRow label="Pass Accuracy" home={match.stats.passAccuracy[0]} away={match.stats.passAccuracy[1]} suffix="%" />
      </div>
    </div>
  )

  const timelineContent = (
    <div className="rounded-xl border border-border bg-card p-6">
      <Timeline match={match} />
    </div>
  )

  const lineupContent = (
    <div className="grid gap-4 md:grid-cols-2">
      {[match.home, match.away].map((teamId) => {
        const t = getTeam(teamId)
        const squad = teamPlayers(teamId)
        return (
          <div key={teamId} className="rounded-xl border border-border bg-card p-6">
            <div className="mb-4 flex items-center gap-2.5">
              <Crest team={teamId} size={32} />
              <div>
                <p className="font-display font-semibold uppercase tracking-wide">{t.name}</p>
                <p className="text-xs text-muted-foreground">Coach · {t.coach}</p>
              </div>
            </div>
            {squad.length > 0 ? (
              <ul className="divide-y divide-border">
                {squad.map((p) => (
                  <li key={p.id} className="flex items-center gap-3 py-2.5">
                    <span className="tabular font-display grid h-7 w-7 place-items-center rounded bg-elevated text-xs font-bold text-gold">
                      {p.number}
                    </span>
                    <Link href={`/players/${p.id}`} className="text-sm font-medium hover:text-gold">
                      {p.name}
                    </Link>
                    <span className="ml-auto text-xs text-muted-foreground">{p.position}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="py-6 text-center text-sm text-muted-foreground">
                Line-up announced one hour before kick-off.
              </p>
            )}
          </div>
        )
      })}
    </div>
  )

  return (
    <SiteShell>
      <div className="mx-auto max-w-[1100px] px-4 py-8 sm:px-6 lg:px-8">
        <Link
          href="/fixtures"
          className="mb-5 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-gold"
        >
          <ArrowLeft className="h-4 w-4" /> All fixtures
        </Link>

        <ScoreboardHero match={match} />

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {info.map((i) => (
            <div key={i.label} className="rounded-lg border border-border bg-card px-4 py-3">
              <div className="mb-1 flex items-center gap-1.5 text-gold">
                <i.icon className="h-3.5 w-3.5" />
                <span className="text-[11px] uppercase tracking-wide text-muted-foreground">
                  {i.label}
                </span>
              </div>
              <p className="text-sm font-medium">{i.value}</p>
            </div>
          ))}
        </div>

        {match.motm && (
          <div className="mt-4 flex items-center justify-between rounded-xl border border-gold/30 bg-gold-muted p-5">
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-gold text-primary-foreground">
                <Star className="h-5 w-5 fill-current" />
              </span>
              <div>
                <p className="font-display text-xs font-semibold uppercase tracking-widest text-gold">
                  Player of the Match
                </p>
                <p className="font-semibold">{match.motm.player}</p>
              </div>
            </div>
            <span className="tabular font-display text-3xl font-bold text-gold">{match.motm.rating}</span>
          </div>
        )}

        <div className="mt-8">
          <Tabs
            tabs={[
              { id: 'timeline', label: 'Timeline', content: timelineContent },
              { id: 'stats', label: 'Statistics', content: statsContent },
              { id: 'lineups', label: 'Line-ups', content: lineupContent },
            ]}
          />
        </div>
      </div>
    </SiteShell>
  )
}
