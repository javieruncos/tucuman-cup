import { Shell } from '@/components/site/shell'
import { PageHero } from '@/components/site/page-hero'
import { NewsCard } from '@/components/news/news-card'
import { news } from '@/lib/data'

export const metadata = {
  title: 'News — Tucumán Cup',
  description: 'Match reports, features, analysis and interviews from across the Tucumán Cup.',
}

export default function NewsPage() {
  const [featured, ...rest] = news
  const lead = rest.slice(0, 1)
  const grid = rest.slice(1)

  return (
    <Shell>
      <PageHero
        eyebrow="The Newsroom"
        title="News & Features"
        description="Match reports, long-reads and tactical analysis from every corner of the tournament."
      />
      <div className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <NewsCard article={featured} variant="feature" />
          <div className="flex flex-col gap-4">
            {lead.map((a) => (
              <NewsCard key={a.id} article={a} />
            ))}
            {news.slice(3, 5).map((a) => (
              <NewsCard key={a.id} article={a} variant="compact" />
            ))}
          </div>
        </div>

        <div className="mt-10 border-t border-border pt-10">
          <h2 className="mb-6 font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
            Latest Coverage
          </h2>
          <div className="grid gap-4 md:grid-cols-2">
            {grid.map((a) => (
              <NewsCard key={a.id} article={a} />
            ))}
          </div>
        </div>
      </div>
    </Shell>
  )
}
