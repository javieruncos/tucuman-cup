import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Clock, Share2 } from 'lucide-react'
import { Shell } from '@/components/site/shell'
import { NewsCard } from '@/components/news/news-card'
import { Crest } from '@/components/crest'
import { getArticle, getTeam, news } from '@/lib/data'

export function generateStaticParams() {
  return news.map((n) => ({ id: n.id }))
}

export default async function ArticlePage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const article = getArticle(id)
  if (!article) notFound()

  const team = article.team ? getTeam(article.team) : null
  const related = news.filter((n) => n.id !== article.id).slice(0, 3)

  return (
    <Shell>
      {/* Article hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div
          className="pointer-events-none absolute inset-0 opacity-30"
          style={{
            background: team
              ? `radial-gradient(120% 90% at 80% 0%, ${team.color}55, transparent 55%)`
              : undefined,
          }}
          aria-hidden="true"
        />
        <div className="stadium-lights pointer-events-none absolute inset-0 opacity-30" aria-hidden="true" />
        <div className="relative mx-auto max-w-3xl px-4 py-12 md:py-16">
          <Link
            href="/news"
            className="mb-8 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="size-4" />
            Back to News
          </Link>
          <span className="rounded bg-gold px-2 py-0.5 font-[family-name:var(--font-display)] text-[11px] font-bold uppercase tracking-widest text-primary-foreground">
            {article.category}
          </span>
          <h1 className="mt-4 font-[family-name:var(--font-display)] text-3xl font-bold uppercase leading-tight tracking-tight text-balance text-foreground md:text-5xl">
            {article.title}
          </h1>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            {article.excerpt}
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span className="font-medium text-foreground">{article.author}</span>
            <span aria-hidden="true">·</span>
            <span>{article.date}</span>
            <span className="inline-flex items-center gap-1">
              <Clock className="size-3.5" /> {article.readTime}
            </span>
          </div>
        </div>
      </section>

      {/* Body */}
      <article className="mx-auto max-w-3xl px-4 py-12">
        <div className="prose-invert space-y-6">
          {article.body.map((para, i) => (
            <p
              key={i}
              className={
                i === 0
                  ? 'text-lg leading-relaxed text-foreground first-letter:float-left first-letter:mr-3 first-letter:font-[family-name:var(--font-display)] first-letter:text-6xl first-letter:font-bold first-letter:text-primary'
                  : 'text-base leading-relaxed text-muted-foreground'
              }
            >
              {para}
            </p>
          ))}
        </div>

        {team && (
          <Link
            href={`/teams/${team.id}`}
            className="mt-10 flex items-center gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/50"
          >
            <Crest team={team} size={48} />
            <div className="flex-1">
              <p className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                Related Club
              </p>
              <p className="font-[family-name:var(--font-display)] text-lg font-semibold uppercase text-foreground">
                {team.name}
              </p>
            </div>
            <span className="text-sm text-primary">View profile →</span>
          </Link>
        )}

        <button className="mt-8 inline-flex items-center gap-2 rounded-full border border-border px-4 py-2 text-sm text-muted-foreground transition-colors hover:border-primary/50 hover:text-foreground">
          <Share2 className="size-4" />
          Share this story
        </button>
      </article>

      {/* Related */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-12">
          <h2 className="mb-6 font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
            More Stories
          </h2>
          <div className="grid gap-4 md:grid-cols-3">
            {related.map((a) => (
              <NewsCard key={a.id} article={a} />
            ))}
          </div>
        </div>
      </section>
    </Shell>
  )
}
