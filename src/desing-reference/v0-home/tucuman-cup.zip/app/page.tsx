import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { SiteShell, SectionHeader } from '@/components/site/shell'
import { LiveTicker } from '@/components/site/live-ticker'
import { MatchCenter } from '@/components/home/match-center'
import { MatchCard } from '@/components/match/match-card'
import { NewsCard } from '@/components/news/news-card'
import { StandingsTable } from '@/components/standings-table'
import { TopScorers } from '@/components/top-scorers'
import { TeamCard } from '@/components/team-card'
import { Sponsors } from '@/components/home/sponsors'
import { matches, news, teamList, tournamentInfo } from '@/lib/data'

function ViewAll({ href }: { href: string }) {
  return (
    <Link
      href={href}
      className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground transition-colors hover:text-gold"
    >
      View all <ArrowRight className="h-4 w-4" />
    </Link>
  )
}

export default function HomePage() {
  const upcoming = matches.filter((m) => m.status === 'upcoming')
  const featured = news.find((n) => n.featured)!
  const rest = news.filter((n) => !n.featured).slice(0, 4)

  return (
    <SiteShell>
      <LiveTicker />

      <div className="mx-auto max-w-[1400px] px-4 py-8 sm:px-6 lg:px-8">
        {/* Match Center — the identity of the product */}
        <div className="animate-rise">
          <MatchCenter />
        </div>

        {/* Season pulse */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            ['Teams', tournamentInfo.teamsCount],
            ['Matches Played', tournamentInfo.matchesPlayed],
            ['Goals Scored', tournamentInfo.goalsScored],
            ['Goals / Match', tournamentInfo.avgGoals],
          ].map(([label, value]) => (
            <div key={label} className="rounded-lg border border-border bg-card px-4 py-3">
              <p className="tabular font-display text-2xl font-bold text-gold">{value}</p>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>

        {/* Upcoming */}
        <section className="mt-16">
          <SectionHeader
            eyebrow="Next up"
            title="Upcoming Matches"
            action={<ViewAll href="/fixtures" />}
          />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        </section>

        {/* Featured news */}
        <section className="mt-16">
          <SectionHeader eyebrow="Editorial" title="Featured News" action={<ViewAll href="/news" />} />
          <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
            <NewsCard article={featured} variant="feature" />
            <div className="flex flex-col gap-4">
              {rest.map((a) => (
                <NewsCard key={a.id} article={a} variant="compact" />
              ))}
            </div>
          </div>
        </section>

        {/* Standings + Top scorers */}
        <section className="mt-16 grid gap-8 lg:grid-cols-[1.5fr_1fr]">
          <div>
            <SectionHeader eyebrow="Table" title="Standings" action={<ViewAll href="/standings" />} />
            <StandingsTable />
          </div>
          <div>
            <SectionHeader eyebrow="Golden boot" title="Top Scorers" action={<ViewAll href="/stats" />} />
            <TopScorers limit={6} />
          </div>
        </section>

        {/* Teams */}
        <section className="mt-16">
          <SectionHeader eyebrow="The clubs" title="Teams" action={<ViewAll href="/teams" />} />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {teamList.slice(0, 8).map((t) => (
              <TeamCard key={t.id} team={t} />
            ))}
          </div>
        </section>

        {/* Sponsors */}
        <section className="mt-16">
          <Sponsors />
        </section>
      </div>
    </SiteShell>
  )
}
