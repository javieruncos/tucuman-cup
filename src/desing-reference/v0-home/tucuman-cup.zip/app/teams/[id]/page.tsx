import { notFound } from 'next/navigation'
import Link from 'next/link'
import { CalendarDays, MapPin, User, Trophy, ArrowLeft } from 'lucide-react'
import { Shell } from '@/components/site/shell'
import { Crest } from '@/components/crest'
import { FormDots } from '@/components/badges'
import {
  teams,
  teamList,
  getStanding,
  teamPlayers,
  matches,
  standings,
  type TeamId,
} from '@/lib/data'

export function generateStaticParams() {
  return teamList.map((t) => ({ id: t.id }))
}

export default async function TeamProfilePage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const team = teams[id as TeamId]
  if (!team) notFound()

  const standing = getStanding(team.id)
  const squad = teamPlayers(team.id)
  const teamMatches = matches.filter(
    (m) => m.home === team.id || m.away === team.id,
  )

  const stats = [
    { label: 'Founded', value: team.founded },
    { label: 'Stadium', value: team.stadium },
    { label: 'City', value: team.city },
    { label: 'Head Coach', value: team.coach },
  ]

  return (
    <Shell>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div
          className="pointer-events-none absolute inset-0 opacity-25"
          style={{
            background: `radial-gradient(120% 90% at 15% 0%, ${team.color}55 0%, transparent 60%)`,
          }}
          aria-hidden="true"
        />
        <div className="stadium-lights pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
        <div className="relative mx-auto max-w-6xl px-4 py-12 md:py-16">
          <Link
            href="/teams"
            className="mb-8 inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="size-4" />
            All Clubs
          </Link>
          <div className="flex flex-col items-start gap-6 md:flex-row md:items-center">
            <Crest team={team} size={96} />
            <div>
              <p className="font-mono text-xs uppercase tracking-[0.3em] text-primary">
                {team.city}
              </p>
              <h1 className="mt-2 font-[family-name:var(--font-display)] text-4xl font-bold uppercase tracking-tight text-foreground md:text-6xl">
                {team.name}
              </h1>
              {standing && (
                <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
                  <span className="inline-flex items-center gap-2">
                    <Trophy className="size-4 text-primary" />
                    {standing.points} pts · #{standings_rank(team.id)} in table
                  </span>
                  <FormDots form={standing.form} />
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-12">
        {/* Club facts */}
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="bg-card p-5">
              <p className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                {s.label}
              </p>
              <p className="mt-2 font-[family-name:var(--font-display)] text-lg font-semibold uppercase text-foreground">
                {s.value}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-[1.4fr_1fr]">
          {/* Squad */}
          <section>
            <h2 className="mb-5 font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
              Squad
            </h2>
            {squad.length > 0 ? (
              <ul className="overflow-hidden rounded-xl border border-border">
                {squad.map((p, i) => (
                  <li
                    key={p.id}
                    className={`flex items-center gap-4 p-4 ${i % 2 === 0 ? 'bg-card' : 'bg-card/50'}`}
                  >
                    <span className="w-8 text-center font-[family-name:var(--font-display)] text-xl font-bold text-primary">
                      {p.number}
                    </span>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{p.name}</p>
                      <p className="text-xs text-muted-foreground">
                        {p.position} · {p.age} yrs · {p.nationality}
                      </p>
                    </div>
                    <div className="hidden text-right sm:block">
                      <p className="font-[family-name:var(--font-display)] text-lg font-bold text-foreground">
                        {p.goals}
                        <span className="ml-1 text-xs font-normal text-muted-foreground">G</span>
                      </p>
                    </div>
                    <div className="rounded-md bg-primary/10 px-2 py-1 text-right">
                      <p className="font-mono text-sm font-semibold text-primary">
                        {p.rating.toFixed(1)}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                Squad list unavailable for this club.
              </p>
            )}
          </section>

          {/* Fixtures */}
          <section>
            <h2 className="mb-5 font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
              Fixtures &amp; Results
            </h2>
            <ul className="space-y-3">
              {teamMatches.map((m) => {
                const isHome = m.home === team.id
                const opp = teams[isHome ? m.away : m.home]
                return (
                  <li key={m.id}>
                    <Link
                      href={`/match/${m.id}`}
                      className="group flex items-center gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
                    >
                      <Crest team={opp} size={36} />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">
                          {isHome ? 'vs' : '@'} {opp.name}
                        </p>
                        <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                          <CalendarDays className="size-3" />
                          {m.date}
                        </p>
                      </div>
                      {m.status === 'upcoming' ? (
                        <span className="font-mono text-sm text-muted-foreground">
                          {m.time}
                        </span>
                      ) : (
                        <span className="font-[family-name:var(--font-display)] text-lg font-bold text-foreground">
                          {isHome
                            ? `${m.homeScore}–${m.awayScore}`
                            : `${m.awayScore}–${m.homeScore}`}
                        </span>
                      )}
                    </Link>
                  </li>
                )
              })}
            </ul>
            <div className="mt-6 rounded-xl border border-border bg-card p-5">
              <p className="flex items-center gap-2 text-sm font-medium text-foreground">
                <MapPin className="size-4 text-primary" />
                {team.stadium}
              </p>
              <p className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                <User className="size-4" />
                Managed by {team.coach}
              </p>
            </div>
          </section>
        </div>
      </div>
    </Shell>
  )
}

function standings_rank(id: TeamId): number {
  return standings.findIndex((s) => s.team === id) + 1
}
