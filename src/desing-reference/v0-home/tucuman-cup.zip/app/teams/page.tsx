import { SiteShell } from '@/components/site/shell'
import { PageHero } from '@/components/site/page-hero'
import { TeamCard } from '@/components/team-card'
import { teamList } from '@/lib/data'

export default function TeamsPage() {
  return (
    <SiteShell>
      <PageHero
        eyebrow="The clubs"
        title="Teams"
        description="Twelve clubs from across the province, each with their own history, colours and ambition, competing for the Tucumán Cup."
      />
      <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {teamList.map((t) => (
            <TeamCard key={t.id} team={t} />
          ))}
        </div>
      </div>
    </SiteShell>
  )
}
