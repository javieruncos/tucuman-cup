import { SiteShell } from '@/components/site/shell'
import { PageHero } from '@/components/site/page-hero'
import { StandingsTable } from '@/components/standings-table'
import { standings, getTeam } from '@/lib/data'

export default function StandingsPage() {
  const leader = getTeam(standings[0].team)
  const topScorerTeam = standings.reduce((a, b) => (a.gf > b.gf ? a : b))
  const bestDefense = standings.reduce((a, b) => (a.ga < b.ga ? a : b))

  return (
    <SiteShell>
      <PageHero
        eyebrow="The table"
        title="Standings"
        description="The current classification of the Tucumán Cup. Top four advance to the semifinals; the bottom two face relegation play-offs."
      />
      <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-6 grid gap-3 sm:grid-cols-3">
          {[
            ['League Leaders', leader.name, `${standings[0].points} pts`],
            ['Most Goals', getTeam(topScorerTeam.team).name, `${topScorerTeam.gf} scored`],
            ['Best Defence', getTeam(bestDefense.team).name, `${bestDefense.ga} conceded`],
          ].map(([label, name, sub]) => (
            <div key={label} className="rounded-xl border border-border bg-card p-5">
              <p className="font-display text-xs font-semibold uppercase tracking-widest text-gold">
                {label}
              </p>
              <p className="font-display mt-2 text-xl font-semibold uppercase tracking-wide">{name}</p>
              <p className="text-sm text-muted-foreground">{sub}</p>
            </div>
          ))}
        </div>
        <StandingsTable />
      </div>
    </SiteShell>
  )
}
