import Link from 'next/link'
import { Settings, Bell, Heart, Ticket, LogOut } from 'lucide-react'
import { Shell } from '@/components/site/shell'
import { Crest } from '@/components/crest'
import { MatchCard } from '@/components/match/match-card'
import { teams, matches } from '@/lib/data'

export const metadata = {
  title: 'My Profile — Tucumán Cup',
}

export default function ProfilePage() {
  const followed = [teams.atl, teams.jve, teams.con]
  const saved = matches.filter((m) => m.status === 'upcoming').slice(0, 2)

  return (
    <Shell>
      {/* Profile header */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="stadium-lights pointer-events-none absolute inset-0 opacity-40" aria-hidden="true" />
        <div
          className="pointer-events-none absolute inset-0 opacity-30"
          style={{
            background:
              'radial-gradient(90% 60% at 20% 0%, color-mix(in oklab, var(--gold) 22%, transparent), transparent 60%)',
          }}
          aria-hidden="true"
        />
        <div className="relative mx-auto flex max-w-6xl flex-col items-start gap-6 px-4 py-12 sm:flex-row sm:items-center">
          <div className="grid size-20 place-items-center rounded-full border-2 border-gold bg-elevated font-[family-name:var(--font-display)] text-3xl font-bold text-primary">
            DS
          </div>
          <div className="flex-1">
            <p className="font-mono text-xs uppercase tracking-[0.3em] text-primary">
              Season Member
            </p>
            <h1 className="mt-1 font-[family-name:var(--font-display)] text-4xl font-bold uppercase tracking-tight text-foreground">
              Diego Sosa
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Member since 2024 · Following {followed.length} clubs
            </p>
          </div>
          <div className="flex gap-2">
            <button className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 text-sm text-muted-foreground transition-colors hover:text-foreground">
              <Settings className="size-4" /> Settings
            </button>
            <Link
              href="/login"
              className="inline-flex items-center gap-2 rounded-lg border border-border px-4 py-2.5 text-sm text-muted-foreground transition-colors hover:border-destructive/50 hover:text-destructive"
            >
              <LogOut className="size-4" /> Sign out
            </Link>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-6xl px-4 py-12">
        {/* Quick stats */}
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border md:grid-cols-4">
          {[
            { icon: Heart, label: 'Clubs Followed', value: followed.length },
            { icon: Ticket, label: 'Saved Fixtures', value: saved.length },
            { icon: Bell, label: 'Alerts On', value: 6 },
            { icon: Settings, label: 'Predictions', value: 12 },
          ].map((s) => (
            <div key={s.label} className="bg-card p-5">
              <s.icon className="size-5 text-primary" />
              <p className="mt-3 font-[family-name:var(--font-display)] text-3xl font-bold text-foreground">
                {s.value}
              </p>
              <p className="font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
                {s.label}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.2fr]">
          {/* Followed clubs */}
          <section>
            <h2 className="mb-5 font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
              My Clubs
            </h2>
            <ul className="space-y-3">
              {followed.map((t) => (
                <li key={t.id}>
                  <Link
                    href={`/teams/${t.id}`}
                    className="group flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/50"
                  >
                    <Crest team={t} size={44} />
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{t.name}</p>
                      <p className="text-xs text-muted-foreground">{t.stadium}</p>
                    </div>
                    <Heart className="size-4 fill-primary text-primary" />
                  </Link>
                </li>
              ))}
            </ul>
          </section>

          {/* Saved fixtures */}
          <section>
            <h2 className="mb-5 font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
              Saved Fixtures
            </h2>
            <div className="space-y-3">
              {saved.map((m) => (
                <MatchCard key={m.id} match={m} />
              ))}
            </div>
          </section>
        </div>
      </div>
    </Shell>
  )
}
