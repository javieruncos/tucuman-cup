import { SiteShell } from '@/components/site/shell'
import { PageHero } from '@/components/site/page-hero'
import { MatchCard } from '@/components/match/match-card'
import { Tabs } from '@/components/tabs'
import { matches } from '@/lib/data'

function Grid({ list }: { list: typeof matches }) {
  if (list.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card/40 py-16 text-center">
        <p className="font-display text-lg font-semibold uppercase tracking-wide text-muted-foreground">
          No matches here
        </p>
        <p className="mt-1 text-sm text-muted-foreground">Check back closer to the round.</p>
      </div>
    )
  }
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {list.map((m) => (
        <MatchCard key={m.id} match={m} />
      ))}
    </div>
  )
}

export default function FixturesPage() {
  const live = matches.filter((m) => m.status === 'live' || m.status === 'halftime')
  const upcoming = matches.filter((m) => m.status === 'upcoming')
  const results = matches.filter((m) => m.status === 'finished')

  return (
    <SiteShell>
      <PageHero
        eyebrow="Calendar"
        title="Fixtures & Results"
        description="Every match of the Tucumán Cup — live now, coming up, and the full record of results across the season."
      />
      <div className="mx-auto max-w-[1400px] px-4 py-10 sm:px-6 lg:px-8">
        <Tabs
          tabs={[
            { id: 'all', label: 'All', content: <Grid list={matches} /> },
            { id: 'live', label: `Live (${live.length})`, content: <Grid list={live} /> },
            { id: 'upcoming', label: 'Upcoming', content: <Grid list={upcoming} /> },
            { id: 'results', label: 'Results', content: <Grid list={results} /> },
          ]}
        />
      </div>
    </SiteShell>
  )
}
