'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Trophy, Mail, Lock, ArrowRight } from 'lucide-react'

export default function LoginPage() {
  const [mode, setMode] = useState<'login' | 'register'>('login')

  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden bg-background px-4 py-12">
      {/* Ambient stadium glow */}
      <div className="stadium-lights pointer-events-none absolute inset-0 opacity-50" aria-hidden="true" />
      <div
        className="pointer-events-none absolute inset-0 opacity-40"
        style={{
          background:
            'radial-gradient(70% 50% at 50% 0%, color-mix(in oklab, var(--gold) 22%, transparent), transparent 70%)',
        }}
        aria-hidden="true"
      />

      <div className="relative w-full max-w-md">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2.5">
          <span className="grid size-10 place-items-center rounded-md bg-gold text-primary-foreground">
            <Trophy className="size-5" />
          </span>
          <span className="font-[family-name:var(--font-display)] text-xl font-bold uppercase tracking-widest text-foreground">
            Tucumán Cup
          </span>
        </Link>

        <div className="rounded-2xl border border-border bg-card/80 p-8 backdrop-blur">
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-lg bg-elevated p-1">
            {(['login', 'register'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-md py-2 text-sm font-semibold uppercase tracking-wide transition-colors ${
                  mode === m
                    ? 'bg-gold text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Register'}
              </button>
            ))}
          </div>

          <h1 className="font-[family-name:var(--font-display)] text-2xl font-bold uppercase tracking-tight text-foreground">
            {mode === 'login' ? 'Welcome back' : 'Join the terrace'}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {mode === 'login'
              ? 'Sign in to follow your clubs and save fixtures.'
              : 'Create an account to personalise your match centre.'}
          </p>

          <form
            className="mt-6 space-y-4"
            onSubmit={(e) => e.preventDefault()}
          >
            {mode === 'register' && (
              <Field label="Full name" htmlFor="name">
                <input
                  id="name"
                  type="text"
                  placeholder="Diego Sosa"
                  className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
                />
              </Field>
            )}
            <Field label="Email" htmlFor="email" icon={<Mail className="size-4" />}>
              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
              />
            </Field>
            <Field label="Password" htmlFor="password" icon={<Lock className="size-4" />}>
              <input
                id="password"
                type="password"
                placeholder="••••••••"
                className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
              />
            </Field>

            {mode === 'login' && (
              <div className="text-right">
                <button type="button" className="text-xs text-primary hover:underline">
                  Forgot password?
                </button>
              </div>
            )}

            <button
              type="submit"
              className="group flex w-full items-center justify-center gap-2 rounded-lg bg-gold py-3 text-sm font-semibold uppercase tracking-wide text-primary-foreground transition-colors hover:bg-gold-strong"
            >
              {mode === 'login' ? 'Sign In' : 'Create Account'}
              <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </button>
          </form>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            By continuing you agree to the Tucumán Cup terms of service.
          </p>
        </div>
      </div>
    </main>
  )
}

function Field({
  label,
  htmlFor,
  icon,
  children,
}: {
  label: string
  htmlFor: string
  icon?: React.ReactNode
  children: React.ReactNode
}) {
  return (
    <label htmlFor={htmlFor} className="block">
      <span className="mb-1.5 block font-mono text-[0.65rem] uppercase tracking-[0.2em] text-muted-foreground">
        {label}
      </span>
      <span className="flex items-center gap-2.5 rounded-lg border border-border bg-elevated px-3.5 py-3 transition-colors focus-within:border-primary/60">
        {icon && <span className="text-muted-foreground">{icon}</span>}
        {children}
      </span>
    </label>
  )
}
