'use client'

import { useState } from 'react'
import { ArrowLeft, Bell, CalendarDays, ChevronRight, Clock3, Flag, MapPin, Menu, MoreHorizontal, Share2, Shield, Trophy, Users, Zap } from 'lucide-react'

const events = [
  { minute: "12'", type: 'goal', team: 'San Martín', player: 'Nicolás Moreno', detail: 'Asistencia de Lucas González' },
  { minute: "34'", type: 'yellow', team: 'Atlético Tucumán', player: 'Matías Orihuela', detail: 'Falta táctica' },
  { minute: "58'", type: 'goal', team: 'Atlético Tucumán', player: 'Mateo Coronel', detail: 'Asistencia de Renzo Tesuri' },
  { minute: "76'", type: 'sub', team: 'San Martín', player: 'Sale: Lucas González', detail: 'Entra: Juan Imbert' },
]

const form = ['W', 'W', 'D', 'W', 'L']

function Crest({ team, color }: { team: string; color: string }) {
  return <div className="crest" style={{ '--crest': color } as React.CSSProperties} aria-label={`${team} crest`}><Shield size={26} strokeWidth={1.4} /><span>{team.split(' ').map(word => word[0]).join('').slice(0, 3)}</span></div>
}

function Stat({ label, home, away, width }: { label: string; home: string; away: string; width: number }) {
  return <div className="stat-row"><div className="stat-values"><strong>{home}</strong><span>{label}</span><strong>{away}</strong></div><div className="stat-track"><span style={{ width: `${width}%` }} /></div></div>
}

export default function Page() {
  const [tab, setTab] = useState('Resumen')
  return (
    <main className="site-shell">
      <nav className="topbar"><div className="nav-inner"><button className="icon-button" aria-label="Open menu"><Menu size={20} /></button><a className="brand" href="#top"><span className="brand-mark">TC</span><span>TUCUMÁN <b>CUP</b></span></a><div className="nav-links"><a href="#matches">Partidos</a><a href="#table">Tabla</a><a href="#teams">Equipos</a><a href="#news">Noticias</a></div><div className="nav-actions"><button className="icon-button" aria-label="Notifications"><Bell size={18} /></button><button className="profile">JD</button></div></div></nav>

      <div className="page-wrap" id="top">
        <div className="crumbs"><a href="#matches"><ArrowLeft size={14} /> Partidos</a><ChevronRight size={14} /><span>Fecha 3 · Zona A</span></div>
        <section className="match-hero">
          <div className="hero-head"><div><div className="eyebrow"><span className="live-dot" /> FINALIZADO · FECHA 3</div><h1>Un clásico con historia</h1><p className="muted">Copa Tucumán 2024 · Zona A</p></div><div className="hero-actions"><button className="outline-button"><Share2 size={15} /> Compartir</button><button className="outline-button only-icon" aria-label="More options"><MoreHorizontal size={18} /></button></div></div>
          <div className="scoreboard"><div className="team-side"><Crest team="San Martín" color="#d8a62c" /><h2>San Martín<br /><span>de Tucumán</span></h2><p>Local</p></div><div className="score-center"><div className="score"><strong>1</strong><i>—</i><strong>1</strong></div><div className="score-status">90+4&apos; · Final</div><div className="venue"><MapPin size={13} /> Estadio La Ciudadela</div></div><div className="team-side away"><Crest team="Atlético Tucumán" color="#4b8aab" /><h2>Atlético<br /><span>Tucumán</span></h2><p>Visitante</p></div></div>
          <div className="match-meta"><span><CalendarDays size={15} /> Sábado, 17 de agosto de 2024</span><span><Clock3 size={15} /> 16:00 hs</span><span><Users size={15} /> 24.630 espectadores</span></div>
        </section>

        <div className="tabs" role="tablist">{['Resumen', 'Alineaciones', 'Estadísticas'].map(item => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)} role="tab" aria-selected={tab === item}>{item}</button>)}</div>
        {tab === 'Resumen' && <div className="content-grid">
          <section className="panel events-panel"><div className="panel-title"><div><span className="section-kicker">LO QUE PASÓ</span><h3>Eventos del partido</h3></div><Flag size={19} /></div><div className="timeline">{events.map((event, index) => <div className="event" key={`${event.minute}-${event.player}`}><div className="event-time">{event.minute}</div><div className={`event-icon ${event.type}`}>{event.type === 'goal' ? <Zap size={14} /> : event.type === 'yellow' ? <span /> : <Users size={14} />}</div><div className="event-copy"><strong>{event.player}</strong><span>{event.team} · {event.detail}</span></div><span className="event-team">{index % 2 === 0 ? 'SMT' : 'AT'}</span></div>)}</div><button className="text-button">Ver todos los eventos <ChevronRight size={15} /></button></section>
          <section className="panel stats-panel"><div className="panel-title"><div><span className="section-kicker">LOS NÚMEROS</span><h3>Estadísticas</h3></div><span className="live-label">PARTIDO</span></div><Stat label="Posesión" home="48%" away="52%" width={48} /><Stat label="Tiros al arco" home="5" away="4" width={56} /><Stat label="Tiros totales" home="12" away="10" width={55} /><Stat label="Corners" home="6" away="3" width={67} /><Stat label="Faltas" home="14" away="11" width={56} /><Stat label="Tarjetas" home="2" away="3" width={40} /></section>
          <aside className="side-column"><section className="panel table-panel"><div className="panel-title"><div><span className="section-kicker">COPA TUCUMÁN</span><h3>Zona A</h3></div><Trophy size={19} /></div><div className="table-labels"><span>Equipo</span><span>PTS</span></div>{[['1','Atlético Tucumán','7'],['2','San Martín','5'],['3','Central Norte','3'],['4','Lastenia','1']].map(row => <div className="table-row" key={row[0]}><b>{row[0]}</b><span className="mini-team"><Crest team={row[1]} color={row[0] === '1' ? '#4b8aab' : '#d8a62c'} />{row[1]}</span><strong>{row[2]}</strong></div>)}<button className="text-button">Ver tabla completa <ChevronRight size={15} /></button></section><section className="panel form-panel"><div className="panel-title"><div><span className="section-kicker">RACHA RECIENTE</span><h3>San Martín</h3></div><span className="team-code">SMT</span></div><div className="form-badges">{form.map((result, i) => <span className={result.toLowerCase()} key={i}>{result}</span>)}</div><p className="muted small">Últimos 5 partidos</p></section></aside>
        </div>}
        {tab !== 'Resumen' && <section className="empty-state panel"><Shield size={34} /><h3>{tab}</h3><p>Vista de referencia preparada para conectar con los datos reales del partido.</p></section>}
        <section className="related" id="matches"><div className="related-head"><div><span className="section-kicker">TAMBIÉN EN LA FECHA 3</span><h2>Más partidos</h2></div><a href="#matches">Ver todos <ChevronRight size={15} /></a></div><div className="match-cards">{[['Central Norte','Lastenia','2','0','Finalizado'],['Bella Vista','Concepción FC','18:30','—','Próximo partido']].map(match => <article className="match-card" key={match[0]}><div className="card-top"><span>Zona A</span><span>{match[4]}</span></div><div className="card-teams"><span><Crest team={match[0]} color="#697785" />{match[0]}</span><b>{match[2]}</b><i>—</i><b>{match[3]}</b><span><Crest team={match[1]} color="#a8784e" />{match[1]}</span></div><div className="card-bottom"><MapPin size={13} /> Estadio Provincial</div></article>)}</div></section>
        <footer><span className="brand"><span className="brand-mark">TC</span><span>TUCUMÁN <b>CUP</b></span></span><span>Visual prototype · sample data</span></footer>
      </div>
    </main>
  )
}
